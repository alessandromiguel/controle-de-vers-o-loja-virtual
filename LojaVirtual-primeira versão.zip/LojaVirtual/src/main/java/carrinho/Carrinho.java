package carrinho;

import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import beans.Produto;


@ManagedBean
@SessionScoped
public class Carrinho {

	  private List<Item> itens = new ArrayList<Item>();
	  
	  private Double total = 0.0;

	  
	  public void remover(Item item){
		  itens.remove(item);
		  
	  }
	  
	  public void adiciona(Produto produto) {
		  Item item = new Item();
		  item.setProduto(produto);
		    itens.add(item);
		    item.setQuantidade(1);
		    
		    total += item.getProduto().getPreco() * item.getQuantidade();
		  }

	public List<Item> getItens() {
		return itens;
	}

	public void setItens(List<Item> itens) {
		this.itens = itens;
	}

	public Double getTotal() {
		return total;
	}

	public void setTotal(Double total) {
		this.total = total;
	} 
	}
